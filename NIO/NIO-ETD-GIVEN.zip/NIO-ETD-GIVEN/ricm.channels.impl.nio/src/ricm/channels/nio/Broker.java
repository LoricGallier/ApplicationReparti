package ricm.channels.nio;

import ricm.channels.IBroker;
import ricm.channels.IBrokerListener;

/**
 * Broker implementation
 */

public class Broker implements IBroker {


	public Broker() throws Exception {
		// to complete
	}


	@Override
	public void setListener(IBrokerListener l) {
		// to complete
	}

	@Override
	public boolean connect(String host, int port) {
		// to complete
		return false;
	}

	@Override
	public boolean accept(int port) {
		// to complete
		return false;
	}


	public void run() {
		// TODO Auto-generated method stub
		
	}

}
