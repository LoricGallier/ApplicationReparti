package ricm.channels.nio;

import ricm.channels.IChannel;
import ricm.channels.IChannelListener;

public class Channel implements IChannel {

	@Override
	public void setListener(IChannelListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void send(byte[] bytes, int offset, int count) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void send(byte[] bytes) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean closed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	// to complete
}
